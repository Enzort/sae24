Le dossier du rendu final de ma sae comporte 4 fichiers python :
	

	- Le script "BD" qui est le script qui correspond au CLI
	- Le script "BD2" qui est le script permettant de créer ma base de donnée avec mes tables d'abord vide, puis qui insère des données grâce aux csv présents dans le dossier.
	Il permet aussi de stocker les différentes fonctions CRUD pour mon site.
	- Le script "interfaceWeb" qui une fois exécuté, lance le serveur localhost avec les différentes pages de mon site.
	- Le script "Sqlite" qui est une création de ma base de donnée sur Sqlite.


Informations complémentaires :


	- Lors de la première exécution du script, il se peut que la connexion à la base de donnée soit refusée, il faut alors le lancer une deuxième fois.
	- Les identifiants sont "admin" pour les deux champs, il faut alors bien vérifier avant de lancer le script.


Modifications depuis le dernier livrable :


	- Ajout de la modification d'un joueur
	- Ajout des propositions de transferts et leurs affichages